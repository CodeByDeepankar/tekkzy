// MongoDB integration removed. This module remains as a no-op placeholder.
module.exports = async () => {
    throw new Error('MongoDB has been removed from this backend.');
};
