# Beginner Mock Commands

Use these commands from the `backend` folder.

This folder now has 6 mock event files:
- `signup-event.json`
- `signin-event.json`
- `forgot-password-event.json`
- `create-message-event.json`
- `update-message-event.json`
- `delete-message-event.json`

## 1) Sign Up (create a new account)
```bash
serverless invoke local --function api --path mocks/signup-event.json
```

## 2) Sign In (log in)
```bash
serverless invoke local --function api --path mocks/signin-event.json
```

## 3) Forgot Password
```bash
serverless invoke local --function api --path mocks/forgot-password-event.json
```

## 4) Create Message
```bash
serverless invoke local --function api --path mocks/create-message-event.json
```

## 5) Update Message
```bash
serverless invoke local --function api --path mocks/update-message-event.json
```

## 6) Delete Message
```bash
serverless invoke local --function api --path mocks/delete-message-event.json
```

Notes for beginners:
- `signup` uses route `/api/auth/register`.
- `signin` uses route `/api/auth/login`.
- `forgot-password` uses route `/api/auth/forgot-password`.
- `create`, `update`, and `delete` are protected routes and include a sample Bearer token.
- `update` and `delete` use a sample contact ID: `0e88a504-5395-4fc6-97a0-62c80ff55e2b`.