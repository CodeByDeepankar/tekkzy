// MongoDB model removed. Contact data now stored in DynamoDB.
module.exports = {};
