// MongoDB model removed. User data now stored in DynamoDB.
module.exports = {};
